export const showLoading = (option={}) => {
    uni.showLoading(option);
}

export const hideLoading = () => {
    uni.hideLoading();
}
